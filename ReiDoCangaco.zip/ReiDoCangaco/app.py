from flask import Flask, request, redirect, session, url_for, render_template
import mysql.connector
import re 

app = Flask (__name__)

app.secret_key = 'CaMeLo'

conectar = mysql.connector.connect(host="localhost", user="root", passwd="123456789", database="reidocangaco")
cursor = conectar.cursor()

@app.route('/pythonlogin/', methods=['GET', 'POST'])
def login():
  
    # Erro no login
    msg = ''
 
    if request.method == 'POST' and 'username' in request.form and 'password' in request.form:
        # Variáveis do usuário
        username = request.form['username']
        password = request.form['password']
        # Verifica se a conta  existe
        cursor.execute('SELECT * FROM contas_acesso WHERE username = %s AND password = %s', (username, password))
        account = cursor.fetchone()
   
    # Usuário existe
        if account:
            # Cria sessão
            session['loggedin'] = True
            session['id'] = account[0]
            session['username'] = account[2]
            return redirect(url_for('home'))
        else:
            # Conta não existe
            msg = 'Usuário ou Senha incorretos!'
    
    return render_template('index.html', msg=msg)

@app.route('/')
# http://localhost:5000/home - login realizado com sucesso
def home():
    # usuário logado?
    if 'loggedin' in session:
        return render_template('home.html', username=session['username'])
    return redirect(url_for('login'))

# http://localhost:5000/profile - Informações do usuário
@app.route('/profile')
def profile(): 
  
    # Verifica se o usuário está logado
    if 'loggedin' in session:
        
        cursor.execute('SELECT * FROM contas_acesso WHERE id = %s', [session['id']])
        account = cursor.fetchone()
        
        return render_template('profile.html', account=account)
    # Usuário não logado, retorna para página de login.
    return redirect(url_for('login'))

# http://localhost:5000/logout - logout do usuário
@app.route('/logout')
def logout():
    # Removendo as informações da sessão
   session.pop('loggedin', None)
   session.pop('id', None)
   session.pop('username', None)
   
   return redirect(url_for('login'))

@app.route('/categoria')
def categoria():
        if 'loggedin' in session:
            return render_template('categoria.html', titulo='Categoria de Produto')
        return redirect(url_for('login'))


app.run()    