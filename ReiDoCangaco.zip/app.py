from flask import Flask, request, redirect, session, url_for, render_template, flash
import mysql.connector
from models.produto import Produto
from models.usuarios import Usuarios

#import re 


app = Flask (__name__)

app.secret_key = 'CaMeLo'

#Criando um objeto MySql connection
conectar = mysql.connector.connect(host="localhost", user="root", passwd="123456789", database="reidocangaco")
cursor = conectar.cursor()

@app.route('/pythonlogin/', methods=['GET', 'POST'])
def login():
  
    # Erro no login
    msg = ''
 
    if request.method == 'POST' and 'username' in request.form and 'password' in request.form:
        # Variáveis do usuário
        username = request.form['username']
        password = request.form['password']
        # Verifica se a conta  existe
        cursor.execute('SELECT * FROM contas_acesso WHERE username = %s AND password = %s', (username, password))
        account = cursor.fetchone()
   
    # Usuário existe
        if account:
            # Cria sessão
            session['loggedin'] = True
            session['id'] = account[0]
            session['username'] = account[2]
            return redirect(url_for('home'))
        else:
            # Conta não existe
            msg = 'Usuário ou Senha incorretos!'
    
    return render_template('index.html', msg=msg)

@app.route('/')
# http://localhost:5000/home - login realizado com sucesso
def home():
    # usuário logado?
    if 'loggedin' in session:
        return render_template('home.html', username=session['username'])
    return redirect(url_for('login'))

# http://localhost:5000/profile - Informações do usuário
@app.route('/profile')
def profile(): 
  
    # Verifica se o usuário está logado
    if 'loggedin' in session:
        
        cursor.execute('SELECT * FROM contas_acesso WHERE id = %s', [session['id']])
        account = cursor.fetchone()
        
        return render_template('profile.html', account=account)
    # Usuário não logado, retorna para página de login.
    return redirect(url_for('login'))

# http://localhost:5000/logout - logout do usuário
@app.route('/logout')
def logout():
    # Removendo as informações da sessão
   session.pop('loggedin', None)
   session.pop('id', None)
   session.pop('username', None)
   
   return redirect(url_for('login'))

@app.route('/usuarios')
def usuarios():
        if 'loggedin' in session:

            #Listar usuários
            sql = "SELECT * FROM USUARIO"
            cursor.execute(sql)
            dadoslistausu = cursor.fetchall()
            
            return render_template('usuarios.html', titulo='Cadastro de Usuários', listausuarios = dadoslistausu)
        return redirect(url_for('login'))
    
#inserir usuarios
@app.route('/insertusuarios', methods = ['POST'])
def insertusuarios():
 
    if request.method == 'POST':
 
        codigo = request.form['codusuario']
        descusuario = request.form['descusuario']
        cpfusuario = request.form['cpfusuario']
        telefoneusuario = request.form['telefoneusuario']
        emailusuario = request.form['emailusuario']
        loginusuario = request.form['loginusuario']
        senhausuario = request.form['senhausuario']
        tipousuario = request.form['tipousuario']
  
        usuarios = Usuarios(codigo, descusuario, cpfusuario, telefoneusuario, emailusuario, loginusuario,senhausuario,tipousuario)
        sql = "INSERT INTO USUARIO (desc_usuario,cpf_usuario,telefone,email,login,senha,cod_tipo) VALUES(%s,%s,%s,%s,%s,%s,%s)"
        dados = (usuarios.cod_usuario, usuarios.desc_usuario,usuarios.cpf_usuario,usuarios.telefone,usuarios.email,usuarios.login,usuarios.senha,usuarios.cod_tipo)
        cursor.execute(sql, dados)
        conectar.commit()
 
        flash("Usuário cadastrado com sucesso!")
    return redirect(url_for('usuarios'))     

#alterar usuario
@app.route('/updateusuarios', methods = ['GET', 'POST'])
def updateusuarios():
 
    if request.method == 'POST':

        usuarios.cod_usuario = request.form.get('codusuario')
        usuarios.desc_usuario = request.form.get('descusuario')
        usuarios.cpf_usuario = request.form.get('cpfusuario')
        usuarios.telefone = request.form.get('telefoneusuario')
        usuarios.email = request.form.get('emailusuario')
        usuarios.login = request.form.get('loginusuario')
        usuarios.senha = request.form.get('senhausuario')
        usuarios.cod_tipo = request.form.get('tipousuario')

        sql = "UPDATE USUARIO SET desc_usuario = %s,cpf_usuario = %s,telefone = %s,email = %s,login = %s,senha = %s,cod_tipo = %s WHERE cod_usuario = %s;"
        dados = (usuarios.desc_usuario,usuarios.cpf_usuario,usuarios.telefone,usuarios.email,usuarios.login,usuarios.senha,usuarios.cod_tipo,usuarios.cod_usuario)
        cursor.execute(sql, dados)
        conectar.commit()

        flash("Usuário alterado com sucesso!")    

    return redirect(url_for('usuarios')) 

#excluir usuario
@app.route('/deleteusuarios/<id>/', methods = ['GET', 'POST'])
def deleteusuarios(id):

    sql = "DELETE FROM USUARIO WHERE cod_usuario=%s;"
     
    cursor.execute(sql, (id,))
    conectar.commit()

    flash("Usuário excluído com sucesso!")
 
    return redirect(url_for('usuarios'))  


@app.route('/categoria')
def categoria():
        if 'loggedin' in session:
            return render_template('categoria.html', titulo='Categoria de Produto')
        return redirect(url_for('login'))

@app.route('/produto')
def produto():
        if 'loggedin' in session:

            #Listar produtos
            sql = "SELECT * FROM PRODUTO"
            cursor.execute(sql)
            dadoslistaprod = cursor.fetchall()
            
            return render_template('produto.html', titulo='Cadastro de produtos', listaprodutos = dadoslistaprod)
        return redirect(url_for('login'))

#inserir produto
@app.route('/insert', methods = ['POST'])
def insert():
 
    if request.method == 'POST':
 
        codigo = request.form['codigo']
        descricao = request.form['descricao']
        codcategoria = 1 #request.form['categoria']
        codunidademedida = 6
        codfornecedor = 5
        preco = request.form['preco']
        qtdestoque = request.form['qtdestoque']
  
 
        produto = Produto(codigo, codcategoria, codunidademedida, codfornecedor, descricao, preco, qtdestoque )
        sql = "INSERT INTO PRODUTO (`cod_produto`,`cod_categoria`,`cod_unidade`,`cod_fornecedor`,`desc_produto`,`preco_produto`,`qtd_estoque`) VALUES(%s,%s,%s,%s,%s,%s,%s)"
        dados = (produto.codigo,produto.codcategoria,produto.codunidademedida,produto.codfornecedor,produto.descricao,produto.preco,produto.qtdestoque)
        cursor.execute(sql, dados)
        conectar.commit()
 
        flash("Produto cadastrado com sucesso!")
    return redirect(url_for('produto'))        

#alterar produto
@app.route('/update', methods = ['GET', 'POST'])
def update():
 
    if request.method == 'POST':
        produtoId= request.form.get('produtoId')
        produto.codigo = request.form.get('codigo')
        produto.codcategoria = 1 #request.form.get('codcategoria')
        produto.codunidademedida = 6 #request.form.get('codunidademedida')
        produto.codfornecedor = 5 #request.form.get('codfornecedor')
        produto.descricao = request.form.get('descricao')
        produto.preco = request.form.get('preco')
        produto.qtdestoque = request.form.get('qtdestoque')

        sql = "UPDATE PRODUTO SET cod_produto = %s,cod_categoria = %s,cod_unidade = %s,cod_fornecedor = %s,desc_produto = %s,preco_produto = %s,qtd_estoque = %s WHERE id_produto = %s;"
        dados = (produto.codigo,produto.codcategoria,produto.codunidademedida,produto.codfornecedor,produto.descricao,produto.preco,produto.qtdestoque,produtoId) 
        cursor.execute(sql, dados)
        conectar.commit()

        flash("Protudo alterado com sucesso!")    


    return redirect(url_for('produto'))        

#excluir produto
@app.route('/delete/<id>/', methods = ['GET', 'POST'])
def delete(id):
    sql = "DELETE FROM PRODUTO WHERE id_produto=%s;"
     
    cursor.execute(sql, (id,))
    conectar.commit()

    flash("Produto excluído com sucesso!")
 
    return redirect(url_for('produto'))

@app.route('/venda')
def venda():
        if 'loggedin' in session:
            return render_template('venda.html', titulo='Venda de Produto')
        return redirect(url_for('login'))

app.run(debug=True)    