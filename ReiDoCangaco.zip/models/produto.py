class Produto:
    def __init__(self, codigo, codcategoria, codunidademedida, codfornecedor, descricao, preco, qtdestoque):
 
        self.codigo = codigo
        self.codcategoria = codcategoria
        self.codunidademedida = codunidademedida
        self.codfornecedor = codfornecedor
        self.descricao = descricao
        self.preco = preco
        self.qtdestoque = qtdestoque

"""
    @classmethod
    def insereProd(cls)



"""