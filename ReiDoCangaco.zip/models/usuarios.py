class Usuarios:
    def __init__(self,cod_usuario,desc_usuario,cpf_usuario,telefone,email,login,senha,cod_tipo):
        self.cod_usuario = cod_usuario
        self.desc_usuario = desc_usuario
        self.cpf_usuario = cpf_usuario
        self.telefone = telefone
        self.email = email
        self.login = login
        self.senha = senha
        self.cod_tipo = cod_tipo